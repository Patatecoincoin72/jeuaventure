﻿"""
Programme réalisé par ta mère
"""

piece=0
mur=0
cle=0


def decrireLaPiece(piece):
    global finito, cle
    if piece==1:
        print("vous vous trouvez dans l'entrée du gâteau")
    elif piece==2:
        print("vous vous trouvez dans la salle à manger")
        if finito==True:
            print("Patate est en train de manger le gateau que vous lui avez préparé")
    elif piece==3:
        print("vous vous trouvez dans la buanderie")
    elif piece==4:
        if finito==False:
            print("vous vous trouvez dans les toilettes de Patate (le canard jaune)")
            print("Patate: Laisse moi faire caca. Vas me faire à manger femme.")
        else:
            print("Vous vous trouvez dans les toilettes de Patate mais il n'est plus là")
    elif piece==5:
        print("vous vous trouvez dans les cuvettes des toilettes de Patate, sortez vite avant qu'il ne vous voie")
        print("vous trouvez une clé")
        cle+=1
    elif piece==6:
        print("vous vous trouvez dans la chambre de Patate")
    elif piece==7:
        print("vous vous trouvez dans la cuisine")
    elif piece==8:
        print("vous vous trouvez dans le passage secret")
    elif piece==9:
        print("vous vous trouvez dans la chambre")
    elif piece==10:
        print("vous vous trouvez dans la penderie")
    elif piece==11:
        print("vous vous trouvez dans la salle de bain")
    elif piece==12:
        print("Bravo, vous vous trouvez dans les toilettes, vous avez fini le jeu")


#la fonction decision permet de se déplacer
#ou non en fonction de la pièce ou l'on se situe


def decision(direction,piece):
    global mur,gateaup,finito
    print("Vous désirez allez au",direction)
    print()
    memorisePiece=piece

    #N
    if direction=='n':
        if piece==3:
            piece=1
        elif piece==5:
            piece=4
        elif piece==4:
            piece=2
        elif piece==2:
            piece=7
        elif piece==11:
            piece=9
        elif piece==12:
            piece=11

    #S
    elif direction=='s':
        if piece==1:
            piece=3
        elif piece==7:
            piece=2
        elif piece==2:
            piece=4
        elif piece==4:
            if finito==True:
                piece=5
            else:
                print("Patate: Je t'ai dit de me laisser tranquille, ne rentre pas dans mes cuvettes !!")
        elif piece==9:
            piece=11
        elif piece==11:
            piece=12

    #E
    elif direction=='e':
        if piece==2:
            piece=1
        elif piece==6:
            piece=2
        elif piece==8:
            piece=7
        elif piece==9:
            piece=8
        elif piece==10:
            piece=9

    #O
    elif direction=='o':
        if piece==1:
            piece=2
        elif piece==2:
            piece=6
        elif piece==7:
            if cle<1:
                print("Cette pièce est inaccessible, il faut une clé pour ouvrir la porte")
            else:
                piece=8
        elif piece==8:
            piece=9
        elif piece==9:
            piece=10


    if memorisePiece==piece:
        print("Vous vous mangez le mur du gâteau")
        mur+=1
        if mur>5:
            print("Vous avez fini les murs de gâteau, la maison s'écroulle")
            menu='q'
    return piece

#recette
gateaup=False
finito=False
oeuf=farine=levure=sucre=chocolat=morts=trop=0

#programme gateau
def gateau(piece):
    global gateaup,finito,oeuf,farine,levure,sucre,chocolat,morts,trop
    if piece==4:
        gateaup=True
    if piece==7 and gateaup==True and finito==False:
        print("La recette d'un gateau:")
        print("   4 oeufs")
        print("   100g de farine")
        print("   un sachet de leuvure chimique")
        print("   200g de sucre")
        print("   tes grand morts˿k̤̼̞͍̳͎͚͈͕͔̲͔̘̦ͫ̓̄̉̅̇̓ͭ̆̃͢͞,̛ͫ̀̃̍ͬ̔͢͝͏͙̦̖͔̝̦̫̪̘̟̞͉̹͡")
        print("   une tablette de chocolat")

        while trop<=3 and (oeuf!=4 or farine!=100 or levure!=1 or sucre!=200 or morts<665 or chocolat!=1):
            recette=input("Ajoutez les ingédients: oeuf, farine, levure, sucre, tablette de chocolat, mes grands morts")
            if recette=="oeuf":
                if oeuf>4:
                    print("Il y a trop d'oeuf dans la recette")
                    trop+=1
                else:
                    oeuf+=1
            elif recette=="farine":
                if farine>100:
                    print("Il y a trop de farine")
                    trop+=1
                else:
                    farine+=100
            elif recette=="levure":
                if levure>1:
                    print("Il y a trop de levure")
                    trop+=1
                else:
                    levure+=1
            elif recette=="sucre":
                if sucre>200:
                    print("Il y a trop de sucre")
                    trop+=1
                else:
                    sucre+=100
            elif recette=="tablette de chocolat":
                if chocolat>1:
                    print("Il y a trop de chocolat")
                    trop+=1
                else:
                    chocolat+=1
            elif recette=="mes grands morts":
                morts+=666
                if morts>666:
                    print("Oui, toujours plus de mortsk̤̼̞͍̳͎͚͈͕͔̲͔̘̦ͫ̓̄̉̅̇̓ͭ̆̃͢͞,̛ͫ̀̃̍ͬ̔͢͝͏͙̦̖͔̝̦̫̪̘̟̞͉̹͡n̛̛̜̠̞̪͎̰̦̟̩̻̣̖̦͇̯̪̏ͣ́̂ͧͮͦ̈́̃ͧ̇̕͢͟")
            else:
                print("Ce n'est pas dans la recette, Patate n'est pas content")
                trop+=1
            print()
            print("oeuf=",oeuf,"sur 4")
            print("farine=",farine,"g sur 100g")
            print("levure=",levure,"sachet sur 1")
            print("sucre=",sucre,"g sur 200g")
            print("chocolat=",chocolat,"tablette sur 1")
            print("morts=",morts,"mort sur n̛̛̜̠̞̪͎̰̦̟̩̻̣̖̦͇̯̪̏ͣ́̂ͧͮͦ̈́̃ͧ̇̕͢͟o̩̩̠͇̖̮̝̟͙͔̞̻͓͂͗̋ͭ̓ͪ̎͆͐͠,̢̛̦̺͔̳̰̫̞͍͕͎̝ͣ̅̋̏̾͛ͨ̍ͦ̃̈̿̃̅̚͝l̨̛͍̼̹̯͎̥̻͎̣͙̠̪̜̂̔͐͂ͭ,̨̛̝͍̘̼̱̙͉̝͙̥̃̄ͣ̇͌ͬ̒͌͟͡l̵̢̤̝̠͓̯̥͉̘̹̮̭͖̞̝͚̮̐́̀̾͑͆̿͂̽̄̎̋ͫ͒̿ͮ")
            print()

        if trop>3:
            print("Vous n'avez pas respecté la recette, le gateau est raté...")
            oeuf=farine=levure=sucre=chocolat=morts=trop=0

        else:
            print("Vous avez réussi le gateau, Patate est content et vous laisse maintenant accès à ses toilettes")
            finito=True
    return finito, gateaup


#programme principal
dansQuellePieceEstLePersonnage=1
menu='0'
while menu!='q':
    gateau(dansQuellePieceEstLePersonnage)
    decrireLaPiece(dansQuellePieceEstLePersonnage)
    print()
    print("Ou désirez-vous aller? -------------------------------------")
    print("n : Nord")
    print("s : Sud")
    print("e : Est")
    print("o : Ouest")
    print("q : quitter")
    print("------------------------------------------------------------")
    print()
    menu=input("votre choix ?")
    dansQuellePieceEstLePersonnage=decision(menu,dansQuellePieceEstLePersonnage)


print("Game Over")